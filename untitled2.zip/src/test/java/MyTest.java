import com.wangqiang.dao.CourseMapper;
import com.wangqiang.dao.SchoolMapper;
import com.wangqiang.pojo.Course;
import com.wangqiang.pojo.School;
import com.wangqiang.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

public class MyTest {
    @Test
    public void test1(){
        SqlSession sqlSession= MybatisUtils.getSqlSession();

        SchoolMapper mapper=sqlSession.getMapper(SchoolMapper.class);
        School school=mapper.getSchool(1);

        System.out.println(school);

        sqlSession.close();
    }
    @Test
    public void getCourseById(){
        SqlSession sqlSession= MybatisUtils.getSqlSession();

        CourseMapper mapper=sqlSession.getMapper(CourseMapper.class);
        Course course=mapper.getCourseById(2);

        System.out.println(course);

        sqlSession.close();
    }
    @Test
    public void addCourse(){
        SqlSession sqlSession= MybatisUtils.getSqlSession();

        CourseMapper mapper=sqlSession.getMapper(CourseMapper.class);
        mapper.addCourse(new Course(6,"⼤数据存储",32,1));

        sqlSession.close();
    }
    @Test
    public void updateCourse(){
        SqlSession sqlSession= MybatisUtils.getSqlSession();

        CourseMapper mapper=sqlSession.getMapper(CourseMapper.class);
        mapper.updateCourse(new Course(4,"高级WEB技术",40,1));

        sqlSession.close();
    }
    @Test
    public void deleteCourse(){
        SqlSession sqlSession= MybatisUtils.getSqlSession();

        CourseMapper mapper=sqlSession.getMapper(CourseMapper.class);
        mapper.deleteCourse(1);

        sqlSession.close();
    }
    @Test
    public void test2(){
        SqlSession sqlSession= MybatisUtils.getSqlSession();

        SchoolMapper mapper=sqlSession.getMapper(SchoolMapper.class);
        School school1=mapper.getSchool(1);
        School school2=mapper.getSchool(2);
        System.out.println(school1);
        System.out.println(school2);
        sqlSession.close();
    }

}
