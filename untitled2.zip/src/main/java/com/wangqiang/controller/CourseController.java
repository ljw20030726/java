package com.wangqiang.controller;

import com.wangqiang.pojo.Course;
import com.wangqiang.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/course")
public class CourseController {
    @Autowired
    @Qualifier("CourseServiceImpl")
    private CourseService courseService;

     //查询全部的课程
   @RequestMapping("/allCourse")
    public String list(Model model) {
       List<Course>list=courseService.queryAllCourse();
       model.addAttribute("list",list);
       return "allCourse";
   }
    @RequestMapping("/toAddCourse")
    public String toAddPaper(){
        return "addCourse";
    }
    //添加书籍的请求
    @RequestMapping("/addCourse")
    public String addBook(Course course){
        System.out.println("addCourse=>"+course);
       courseService.addCourse(course);
        return "redirect:/course/allCourse";
    }


    //    跳转到修改页面
    @RequestMapping("/toUpdate")
    public String toUpdatePaper(Model model, int id) {
       Course course = courseService.queryCourseById(id);
        model.addAttribute("course",course );
        return "updateCourse";
    }
    //修改书籍
    @RequestMapping("/updateCourse")
    public String updateBook(Model model,Course course) {
        System.out.println("updateCourse=>"+course);
        courseService.updateCourse(course);
//         book = booksService.queryBookById(books.getBookID());
//        model.addAttribute("books", books);
        return "redirect:/course/allCourse";
    }
   /* @PostMapping("/updateCourse")
    public Map<String, Object> updateBook(
            @RequestParam("id") Integer courseId,
            @RequestParam("name") String courseName,
            @RequestParam("hour") Integer hour,
            @RequestParam("sid") Integer sid) {
        Map<String, Object> result = new HashMap<>();
        try {
            // 判断新的课程名称是否与已有的课程名称重复
            if (courseService.isCourseNameExist(courseName)) {
                result.put("success", false);
                result.put("message", "课程名称已存在！");
            } else {
                // 更新课程信息
                Course course = courseService.queryCourseById(courseId);
                course.setName(courseName);
                course.setHour(hour);
                course.setSid(sid);
                courseService.updateCourse(course);
                result.put("success", true);
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "课程修改失败！");
        }
        return result;
    }

    */
    //删除书籍
    @RequestMapping("/del/{id}")
    public String deleteBook(@PathVariable("id") int id){
        courseService.deleteCourse(id);
        return "redirect:/course/allCourse";
    }
    //查询功能
    @RequestMapping("/queryCourse")
    public String queryBook(String queryCourseName,Model model){
        Course course =courseService.queryCourseByName(queryCourseName);
        ArrayList<Course> list = new ArrayList<Course>();
        list.add(course);
        if(course == null){
            courseService.queryAllCourse();
            model.addAttribute("error","未查到");
        }
        model.addAttribute("list",list);
        return "allCourse";
    }

    @RequestMapping("/goLogin")
    public String Login(){
        return "login";
    }


    @RequestMapping("/login")
    public String login(HttpSession session, String username, String password,Model model){
        System.out.println("login==>"+username);
        session.setAttribute("userLoginInfo",username);
        model.addAttribute("username",username);
        return "allCourse";
    }
    @RequestMapping("/goOut")
    public String login(HttpSession session){
        session.removeAttribute("userLoginInfo");
        return "allCourse";
    }

}
