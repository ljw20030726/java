package com.wangqiang.dao;

import com.wangqiang.pojo.Course;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CourseMapper {
    List<Course> getCourse();

    Course getCourseById(int id);

    int addCourse(Course course);

    int updateCourse(Course course);

    int deleteCourse(@Param("id") int id);

    boolean isCourseNameExist(@Param("name")String name);
   // int deleteBookById(@Param(value = "bookId") int id);

    List<Course>queryAllCourse();
    //List<Books> queryAllBook(@Param(value = "curPage")int curPage,@Param(value = "pageSize")int pageSize);
    Course queryCourseByName(@Param("name")String name);
}
