package com.wangqiang.dao;

import com.wangqiang.pojo.School;
import org.apache.ibatis.annotations.Param;


public interface SchoolMapper {
    School getSchool(@Param("sid") int id);
}
