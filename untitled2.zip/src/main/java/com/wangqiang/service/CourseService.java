package com.wangqiang.service;

import com.wangqiang.pojo.Course;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CourseService {
      int addCourse(Course course);
      int deleteCourse(int id);
      int updateCourse(Course course);
      Course queryCourseById(int id);
      List<Course> queryAllCourse();
      Course queryCourseByName(String name);
      Boolean isCourseNameExist(String name);
}
