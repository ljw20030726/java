package com.wangqiang.service;

import com.wangqiang.dao.CourseMapper;
import com.wangqiang.pojo.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {
    @Autowired

    private CourseMapper courseMapper;

    public void setCourseMapper(CourseMapper courseMapper) {
        this.courseMapper = courseMapper;
    }

    @Override
    public int addCourse(Course course) {
        return courseMapper.addCourse(course);
    }

    @Override
    public int deleteCourse(int id) {
        return courseMapper.deleteCourse(id);
    }

    @Override
    public int updateCourse(Course course) {
        return courseMapper.updateCourse(course);
    }

    @Override
    public Course queryCourseById(int id) {
        return courseMapper.getCourseById(id);
    }

    @Override
    public List<Course> queryAllCourse() {
        return courseMapper.queryAllCourse();
    }

    @Override
    public Course queryCourseByName(String name) {
        return courseMapper.queryCourseByName(name);
    }

    @Override
    public Boolean isCourseNameExist(String name) {
        return courseMapper.isCourseNameExist(name);
    }
}
