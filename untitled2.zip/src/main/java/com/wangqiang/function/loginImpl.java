package com.wangqiang.function;

public class loginImpl implements login{
    @Override
    public Boolean login(String username,String password) {
       return "admin".equals(username)&&("123").equals(password);
    }
}
