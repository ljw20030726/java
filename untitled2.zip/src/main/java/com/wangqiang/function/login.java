package com.wangqiang.function;

public interface login {
    public Boolean login(String username,String password);
}
